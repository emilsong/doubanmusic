var Settings={}
Settings.configCache={},Settings.setValue=function(e,t){Settings.configCache[e]=t
var a={}
return localStorage.config&&(a=JSON.parse(localStorage.config)),a[e]=t,localStorage.config=JSON.stringify(a),t},Settings.getValue=function(e,t){if(!localStorage.config)return t
var a=JSON.parse(localStorage.config)
return a[e]===void 0?t:(Settings.configCache[e]=a[e],a[e])},Settings.getCacheValue=function(e,t){if(Settings.configCache[e]!==void 0)return Settings.configCache[e]
if(!localStorage.config)return t
var a=JSON.parse(localStorage.config)
return a[e]===void 0?t:(Settings.configCache[e]=a[e],a[e])},Settings.keyExists=function(e){if(!localStorage.config)return!1
var t=JSON.parse(localStorage.config)
return void 0!=t[e]},Settings.setObject=function(e,t){return localStorage[e]=JSON.stringify(t),t},Settings.getObject=function(e){return void 0==localStorage[e]?void 0:JSON.parse(localStorage[e])},Settings.refreshCache=function(){Settings.configCache={}}
var getPlayData=function(){var e=Settings.getObject("playData")
return void 0==e&&(e={playList:[],playListDate:new Date,playIndex:0,channelInfo:{}}),e},getPlayLyric=function(){var e=Settings.getObject("lyric")
return void 0==e&&(e={},Settings.setObject("lyric",e)),e},getKbps=function(){var e=64,t=Settings.getObject("userInfo")
return void 0!=t&&t.is_pro&&(e=Settings.getValue("vipkbps",192),e=e+"&kbps="+e),e}
