$(document).ready(function(){function e(){t.showLike=1==$("#like").attr("checked")?!0:!1,t.showDel=1==$("#del").attr("checked")?!0:!1,t.showPrev=1==$("#prev").attr("checked")?!0:!1,t.showNext=1==$("#next").attr("checked")?!0:!1,t.showLyric=1==$("#lyric").attr("checked")?!0:!1
var e=$(":radio:checked").attr("data-val")
Settings.setValue("vipkbps",e),Settings.setObject("options",t)}var t=Settings.getObject("options")
void 0==t&&(t={showLike:!1,showDel:!0,showPrev:!0,showNext:!0,showLyric:!0},Settings.setObject("options",t)),t.showLike&&$("#like").attr("checked","true"),t.showDel&&$("#del").attr("checked","true"),t.showPrev&&$("#prev").attr("checked","true"),t.showNext&&$("#next").attr("checked","true"),t.showLyric&&$("#lyric").attr("checked","true")
var a=Settings.getValue("vipkbps",192)
$("#k"+a).attr("checked",!0),$("input:checkbox,input:radio").click(function(){e()}),$(".menu a").click(function(){$(".menu a").removeClass("hover"),$(this).addClass("hover"),$("dl").hide(),$("."+$(this).attr("id")).show()})})
