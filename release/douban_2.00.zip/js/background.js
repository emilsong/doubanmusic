function timeSpan(e){var t=e
this.getDays=function(){return Math.floor(this.getHours()/24)},this.getHours=function(){return Math.floor(this.getMinutes()/60)},this.getMinutes=function(){return Math.floor(this.getSeconds()/60)},this.getSeconds=function(){return Math.floor(t/1e3)},this.getMillisecondPart=function(){return t-1e3*this.getSeconds()},this.getSecondPart=function(){return this.getSeconds()-60*this.getMinutes()},this.getMinutePart=function(){return this.getMinutes()-60*this.getHours()},this.getHourPart=function(){return this.getHours()-24*this.getDays()}}var replaceAlbum=function(e){for(i=0;e.length>i;i++)"豆瓣FM"==e[i].albumtitle&&e.slice(i,1)
return e},portLink
chrome.extension.onConnect.addListener(function(e){portLink=e,"dbstyle"==e.name&&(e.postMessage({act:"connected"}),e.onDisconnect.addListener(function(){portLink=null}),e.onMessage.addListener(function(e){switch(e.act){case"playList":player.playList(e.data)
break
case"play":player.play()
break
case"pause":player.pause()
break
case"next":player.playNext()
break
case"prev":player.playPrev()
break
case"mute":player.mute()
break
case"unmute":player.unmute()
break
case"volumn":player.volumn(e.data)
break
case"channel":player.channel(e.data)}}))}),$('<div id="jquery_jplayer_1" class="jp-jplayer"></div>').appendTo("body"),$("#jquery_jplayer_1").jPlayer({ready:function(){},ended:function(){player.playNext()},timeupdate:function(e){if(null!=portLink){var t=e.jPlayer.status.duration-e.jPlayer.status.currentTime
t=$.jPlayer.convertTime(t)
var a=e.jPlayer.status.currentTime/e.jPlayer.status.duration
portLink.postMessage({act:"playing",data:{time:t,percent:a,now:Math.floor(e.jPlayer.status.currentTime)}})}},supplied:"mp3",solution:"html"})
var player={init:function(){},playPrev:function(){var e=getPlayData()
e.playIndex>=1&&(e.playIndex-=1,Settings.setObject("playData",e),player.playSong(e))},playNext:function(){var e=getPlayData()
e.playIndex+=1,Settings.setObject("playData",e),player.playSong(e)},play:function(){$("#jquery_jplayer_1").bind($.jPlayer.event.error,function(){player.playList()}),$("#jquery_jplayer_1").jPlayer("play")},pause:function(){$("#jquery_jplayer_1").jPlayer("pause")},playSong:function(e){var t=e.playList[e.playIndex]
if(void 0==t)player.getPlay(e.channelInfo.id)
else{var a=t.url
if($("#jquery_jplayer_1").jPlayer("setMedia",{mp3:a}).jPlayer("play"),null!=portLink){var n={}
n.act="info",n.data=t,portLink.postMessage(n)}}},playList:function(e){var t=getPlayData()
void 0==e&&(e=t.channelInfo)
var a=getKbps(),n=e.id,r="http://douban.fm/j/mine/playlist?type=n&pb="+a+"&from=mainsite&channel="+n
$.get(r,function(a){$("#jquery_jplayer_1").jPlayer("clearMedia"),t.playListDate=(new Date).getTime(),t.playList=a.song,t.playIndex=0,t.channelInfo=e,Settings.setObject("playData",t),player.playSong(t)})},getPlay:function(e){var t=getKbps(),a="http://douban.fm/j/mine/playlist?type=n&pb="+t+"&from=mainsite&channel="+e
$.get(a,function(e){var t=getPlayData(),a=t.playListDate
if(void 0==a)t.playList=e.song,t.playIndex=0
else{var n=(new Date).getTime()-a,r=new timeSpan(n)
r.getHourPart()>1?(t.playList=e.song,t.playIndex=0):t.playList=t.playList.concat(e.song)}t.playListDate=(new Date).getTime(),Settings.setObject("playData",t),player.playSong(t)})},mute:function(){$("#jquery_jplayer_1").jPlayer("mute")},unmute:function(){$("#jquery_jplayer_1").jPlayer("unmute")}}
