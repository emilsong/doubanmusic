$(document).ready(function(){var t=Settings.getObject("options")
void 0==t&&(t={showLike:!1,showDel:!0,showPrev:!0,showNext:!0,showLyric:!0},Settings.setObject("options",t)),t.showDel&&$(".jp-del").show(),t.showPrev&&$(".jp-previous").show(),t.showNext&&$(".jp-next").show()
var e=!1,a={},n=chrome.extension.connect({name:"dbstyle"}),r=getPlayData()
try{var l=r.playList[r.playIndex]
void 0==l.public_time&&(l.public_time=""),"1"==l.like&&$(".jp-like").addClass("jp-liked").attr("data-liked","1"),$(".jp-like").attr("data-sid",l.sid),$("#singer").text(l.artist),$("#album").text("<"+l.albumtitle+"> "+l.public_time),$("#cover").attr("src",l.picture),$("#song").text(l.title),r.channelInfo.title&&($("#channel_cover").attr("src",r.channelInfo.cover),$("#channel_title").text(r.channelInfo.title))}catch(s){}n.onMessage.addListener(function(t){switch(t.act){case"info":var n=t.data
$("#cover").attr("src",n.picture),""!=n.album?$("#coverlink").attr("href","http://music.douban.com"+n.album).attr("target","_blank"):$("#coverlink").removeAttr("href"),$("#singer").text(n.artist),void 0==n.public_time&&(n.public_time=""),void 0!=n.albumtitle&&""!=n.albumtitle&&$("#album").text("<"+n.albumtitle+"> "+n.public_time),$("#song").text(n.title),1==n.like?$(".jp-like").addClass("jp-liked").attr("data-liked","1"):$(".jp-like").removeClass("jp-liked"),$(".jp-like").attr("data-sid",n.sid),o.getLyric(n)
break
case"playing":r=getPlayData()
var n=r.playList[r.playIndex]
e||(e=!0,$("#channel_status").removeClass("waiting").addClass("playing"),$(".jp-play").hide(),$(".jp-pause").show(),a=getPlayLyric(),void 0!=a&&a.title!=n.title&&o.getLyric(n)),$(".jp-current-time").text(t.data.time),$(".jp-play-bar").css({width:100*t.data.percent+"%"}),a=getPlayLyric(),void 0!=a&&a.lyric&&void 0!=a.lyric[t.data.now]&&a.title==n.title&&$(".lyric").text(a.lyric[t.data.now])
break
case"connected":}}),$(".tag ul li a").click(function(){$(".tag ul li a").removeClass("hover")
var t=$(this)
t.addClass("hover")
var e=t.attr("data-type")
"cate"!=e?o.get(e,0):($("#cate").show(),$("#lists").hide())}),$("#cate li").bind("click",function(){$("#cate li").removeClass("hover")
var t=$(this)
t.addClass("hover"),o.get("search",0,"genre_id:"+t.attr("data-id"))}),$("#keyword").bind("keydown",function(){13==event.keyCode&&$(".search").trigger("click")}),$("#keyword").focusin(function(){$("#keyword").css({width:"100px"})}).focusout(function(){$("#keyword").css({width:"70px"})}),$(".search").bind("click",function(){$(".tag ul li a").removeClass("hover")
var t=$("#keyword").val()
""!=t&&o.get("search",0,t)}),$(".arrow").bind("click",function(){var t=$(this),e=$(".cates")
0!=e.offset().left?(20==$(".login").offset().left&&$(".login").animate({left:"300px"}),e.animate({left:"0px"},function(){t.addClass("arrow-back"),$(".lyric").removeClass("lyric-normal").addClass("lyric-hover")})):(c.needLogin&&$(".login").animate({left:"0px"}),e.animate({left:"-280px"},function(){t.removeClass("arrow-back"),$(".lyric").removeClass("lyric-hover").addClass("lyric-normal")}))}),$(".jp-next").bind("click",function(){r=getPlayData(),r.playIndex+=1,n.postMessage({act:"next"}),$("#channel_status").addClass("playing").removeClass("waiting"),$(".jp-pause").show(),$(".jp-play").hide()}),$(".jp-del").bind("click",function(){r=getPlayData()
var t=r.playList[r.playIndex]
o.del(t.sid)}),$(".jp-previous").bind("click",function(){r=getPlayData(),r.playIndex>=1&&(r.playIndex-=1,n.postMessage({act:"prev"}))}),$(".jp-pause").bind("click",function(){n.postMessage({act:"pause"}),$("#channel_status").addClass("waiting").removeClass("playing"),$(".jp-play").show(),$(".jp-pause").hide()}),$(".jp-play").bind("click",function(){$("#channel_status").addClass("playing").removeClass("waiting"),n.postMessage({act:"play"}),$(".jp-pause").show(),$(".jp-play").hide()}),$(".jp-mute").bind("click",function(){n.postMessage({act:"mute"}),$(".jp-mute").hide(),$(".jp-unmute").show()}),$(".jp-unmute").bind("click",function(){n.postMessage({act:"unmute"}),$(".jp-unmute").hide(),$(".jp-mute").show()}),$("#user_status").bind("click",function(){c.status?$("#user_menu").toggle():c.init(),setTimeout(function(){$("#user_menu").is(":visible")&&$("body").bind("click",function(){$("#user_menu").hide(),$("body").unbind("click")})},0)}),$(".logout").click(function(){c.logout()}),$("#radio_private").click(function(){o.playChannel("0"),$("#user_menu").hide()}),$("#radio_red").click(function(){o.playChannel("-3"),$("#user_menu").hide()}),$(".jp-like").click(function(){var t=$(this).attr("data-sid"),e=r.channelInfo.id
o.red(t,e)})
var o={config:{hotUrl:"http://douban.fm/j/explore/hot_channels",upUrl:"http://douban.fm/j/explore/up_trending_channels",searchUrl:"http://douban.fm/j/explore/search?query=",tmpl:"<li>					<div data-id='$id$'>						<p title='$intro$' class='layer-cover'></p>						<img src='$img$' />					</div>					<a>$name$</a>				</li>"},get:function(t,e,a){var n
switch(t){case"hot":n=o.config.hotUrl+"?start="+e+"&limit=80"
break
case"up":n=o.config.upUrl+"?start="+e+"&limit=80"
break
case"search":n=o.config.searchUrl+encodeURIComponent(arguments[2])+"&start="+e+"&limit=24"}var r=o.config.tmpl,l=""
$.get(n,function(t){if($(".lists").scrollTop(0),t.data&&t.data.channels){for(i=0;t.data.channels.length>i;i++){var e=t.data.channels[i],n=r.replace("$img$",e.cover)
n=n.replace("$name$",e.name),n=n.replace("$id$",e.id),n=n.replace("$intro$",e.intro),l+=n}$("#cate").hide(),$("#lists").empty().show().append(l),$("#lists li a").bind("click",function(){$(this).siblings("div").trigger("click")}),$("#lists li div").bind("click",function(){var t=$(this),e=$(this).attr("data-id"),a=t.children("img").attr("src"),n=t.parent("li").children("a").text(),i={title:n,cover:a,id:e}
$(".arrow").trigger("click"),c.needLogin=!1,$(".login").css("left","300px"),o.playChannel(i)}),a&&a()}})},playChannel:function(t){var e=t
"-3"==t?e={title:"红心电台",cover:"douban/red.gif",id:"-3"}:"0"==t&&(e={title:"私人电台",cover:"douban/private.gif",id:"0"}),$("#channel_cover").attr("src",e.cover),$("#channel_title").text(e.title),$(".jp-play").hide(),$(".jp-pause").show(),$("#channel_status").addClass("playing").removeClass("waiting"),n.postMessage({act:"playList",data:e})},getLyric:function(e){var n=!1
if(t.showLyric){$(".lyric").text("正在加载歌词")
var i="http://sug.music.baidu.com/info/suggestion?format=json&word=",r="http://music.baidu.com/data/music/fmlink?songIds=",l="http://music.baidu.com"
i+=encodeURIComponent(e.artist+" "+e.title),$.getJSON(i,function(t){t.song.length>0&&(r+=t.song[0].songid,$.getJSON(r,function(t){t.data.songList.length>0&&(l+=t.data.songList[0].lrcLink,$.get(l,function(t){t=t.split("\n")
for(var i=/^((?:\[[\d.:]+?\])+?)([^\[\]]*)$/,r={},l=0,s=t.length;s>l;l+=1){var o,c=t[l].match(i)
if(c){o=c[1].slice(1,-1).split("][")
for(var u,p=0,d=o.length;d>p;p+=1)u=o[p].split(":"),r[60*Number(u[0])+Math.round(u[1])]=c[2]}}a.lyric=r,a.title=e.title,Settings.setObject("lyric",a),n=!0,$(".lyric").text(e.title)}))}))})}n||$(".lyric").html(e.title)},del:function(t){var e="http://douban.fm/j/mine/playlist?type=b&sid="+t+"&pt=100&channel="+r.channelInfo.id+"&pb=64&from=mainsite"
$.get(e,function(){r.playList.splice(r.playIndex,1),r.playIndex-=1,Settings.setObject("playData",r),$(".jp-next").trigger("click")})},red:function(t,e){var a="http://douban.fm/j/mine/playlist?type=r&sid="+t+"&pt=100&channel="+e+"&pb=64&from=mainsite",n="http://douban.fm/j/mine/playlist?type=u&sid="+t+"&pt=100&channel="+e+"&pb=64&from=mainsite",i=a,l=$(".jp-like")
r=getPlayData(),"1"==l.attr("data-liked")?(i=n,l.attr("data-liked","0"),r.playList[r.playIndex].like=0):(l.attr("data-liked","0"),r.playList[r.playIndex].like=1),Settings.setObject("playData",r),l.toggleClass("jp-liked"),$.get(i,function(){})}}
void 0!=r.playList&&0==r.playList.length?o.get("hot",0,function(){$(".arrow").trigger("click")}):o.get("hot",0)
var c={config:{verficIdUrl:"http://douban.fm/j/new_captcha",verficImage:"http://douban.fm/misc/captcha?size=m&id=",loginUrl:"http://douban.fm/j/login"},status:!1,isPro:!1,verfic:function(){$.ajax({type:"GET",url:c.config.verficIdUrl,dataType:"text",success:function(t){var e=c.config.verficImage,a=t.replace('"',"").replace('"',"")
$("#captcha_id").val(a)
var n=$("#captcha")
n.attr("src",e+a),n.click(function(){c.verfic()})}})},init:function(){0==$(".cates").offset().left&&$(".arrow").trigger("click"),$(".login").animate({left:"0px"}),$("#btn-cancel").click(function(){$(".login").animate({left:"300px"})}),c.verfic()
var t=$("#btn-submit"),e=!1
t.click(function(){e||(e=!0,$.ajax({type:"POST",url:c.config.loginUrl,data:$("#login_form").serialize(),success:function(t){if(0==t.r){Settings.setObject("userInfo",t.user_info)
var a=t.user_info
$("#login_password,#captcha_solution").val(""),$(".login").animate({left:"300px"}),$("#user_menu").show(),$("body").bind("click",function(){$("#user_menu").hide(),$("body").unbind("click")}),c.needLogin=!1,c.status=!0,c.isPro=a.is_pro,$("#user_status span").text(a.name),c.isPro?(Settings.setValue("vipkbps",192),$("#user_pro").show(),$("#user_status").attr("title","PRO用户，享受192K高清音质")):($("#user_pro").hide(),$("#user_status").attr("title",""))}else alert(t.err_msg),c.verfic()
e=!1}}))})},checkLogin:function(){chrome.cookies.get({url:"http://douban.fm",name:"dbcl2"},function(t){if(null!=t){c.status=!0
var e=Settings.getObject("userInfo")
void 0!=e&&e.is_pro?(c.isPro=!0,$("#user_status span").text(e.name),$("#user_status").attr("title","PRO用户/192K高清音质"),$("#user_pro").show()):($("#user_pro").hide(),$("#user_status").attr("title",""))}else{$("#user_status span").text("登录"),$("#user_pro").hide(),$("#user_status").attr("title","")
var a=r.channelInfo.id;("-3"==a||"0"==a)&&(c.needLogin=!0,c.init())}})},logout:function(){chrome.cookies.remove({url:"http://douban.fm",name:"dbcl2"}),c.status=!1,$("#user_status span").text("登录"),$("#user_pro").hide(),$("#user_menu").hide()
var t=r.channelInfo.id;("-3"==t||"0"==t)&&(c.needLogin=!0,c.init())}}
c.checkLogin()})
